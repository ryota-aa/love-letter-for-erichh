function generateLetter() {
    let text = document.getElementById("letter").value;
    if (text.trim() === "") {
        alert("Please write something first!");
        return;
    }
    document.getElementById("output").innerText = "❤️ " + text + " ❤️";
}
